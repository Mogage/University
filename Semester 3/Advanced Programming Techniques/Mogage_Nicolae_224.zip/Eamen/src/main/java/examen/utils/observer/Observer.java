package examen.utils.observer;

public interface Observer {
    void update();
}
