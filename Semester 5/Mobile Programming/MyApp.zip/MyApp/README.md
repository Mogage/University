Change log

01 Initial project (Empty Activity)
02 Compose Text component
03 Composable function
04 Layout (Row) & data
05 Layout (Column) & view model
06 State
07 ViewModel & state
08 Navigation & repository
09 List (LazyColumn)
10 Scaffolding
11 Coroutine
12 Remote data source
13 Flow
14 Callback flow & web socket
15 Shared flow
16 Flow as state
17 Room database
18 Data store
